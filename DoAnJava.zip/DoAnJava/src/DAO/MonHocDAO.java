/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import BUS.BUS;
import DTO.MonHoc;
import DTO.SinhVien;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author lythanhphat9523
 */
public class MonHocDAO {
    public static MonHoc selectById(String ID) {
        MonHoc t=new MonHoc();
        try{
            //Buoc 1:Ket noi
            Connection conn= BUS.getConnection();

            //Buoc 2:
            Statement st=conn.createStatement();
            
            //Buoc 3:
            String sql="SELECT * FROM MonHoc WHERE maMaHoc='"+ID+"'";
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                t.setMaMH(rs.getString("maMonHoc"));
                t.setTenMH(rs.getString("tenMonHoc"));
                t.setTinChi(rs.getString("soTinChi"));
                t.setHocPhi(rs.getString("hocPhi"));
            } 
            
            BUS.closeConnection(conn);
        }catch (SQLException e){
            e.printStackTrace(); 
        }
        return t;
    }
    
    public static boolean insert(MonHoc t) {
        try{
            //Buoc 1:
            Connection conn= BUS.getConnection();

            //Buoc 2:
            Statement st=conn.createStatement();
            
            //Buoc 3:
            String sql="INSERT INTO MonHoc(maMonHoc,tenMonHoc,soTinChi,hocPhi" +
                       "VALUES('" +t.getMaMH()+ "',N'" +t.getTenMH()+ "','" +t.getTinChi()+ "',N'" +t.getHocPhi()+ "'";
            
            int ketqua=st.executeUpdate(sql);
            if (ketqua>0) return true;
            
            BUS.closeConnection(conn);
        }catch (SQLException e){
            e.printStackTrace(); 
        }
        return false;
    }
    
    public static boolean update(MonHoc t) {
        
        try{
            //Buoc 1:Ket noi
            Connection conn= BUS.getConnection();

            //Buoc 2:
            Statement st=conn.createStatement();
            
            //Buoc 3:
            String sql="UPDATE MonHoc SET tenMonHoc= N'"+t.getTenMH()+"',soTinChi= '"+t.getTinChi()+"',hocPhi=N'"+t.getHocPhi()+"'";       
            int ketqua=st.executeUpdate(sql);
            if (ketqua>0) return true;
            BUS.closeConnection(conn);
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }
    
    public static boolean delete(String t) {
        try{
            //Buoc 1:Ket noi
            Connection conn= BUS.getConnection();

            //Buoc 2:
            Statement st=conn.createStatement();
            
            //Buoc 3:
            String sql="DELETE FROM MonHoc WHERE maMonHoc='"+ t +"'";
            
            int ketqua=st.executeUpdate(sql);
            if (ketqua>0) return true;
        }catch (SQLException e){
            e.printStackTrace(); 
        }
        return false;
    }
    
    public static ArrayList<MonHoc> selectAll() {
        ArrayList<MonHoc> list =new ArrayList<MonHoc>();
        try{
            //Buoc 1:Ket noi
            Connection conn= BUS.getConnection();

            //Buoc 2:
            Statement st=conn.createStatement();
            
            //Buoc 3:
            
            String sql="SELECT * FROM MonHoc";
            
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                String maMH = rs.getString("maMonHoc");
                String tenMH = rs.getString("tenMonHoc");
                String tinChi= rs.getString("soTinChi");
                String hocPhi= rs.getString("hocPhi");
            
                MonHoc mh= new MonHoc(maMH,tenMH,tinChi,hocPhi);
                list.add(mh);
            }
            
            BUS.closeConnection(conn);
            
        }catch (SQLException e){
            e.printStackTrace(); 
        }
    return list;   
}
    
    public static ArrayList<MonHoc> selectByCondition(String DuLieu,String dieuKien) {
        ArrayList<MonHoc> list =new ArrayList<MonHoc>();
        try{
            //Buoc 1:Ket noi
            Connection conn= BUS.getConnection();

            //Buoc 2:
            Statement st=conn.createStatement();
            
            //Buoc 3:
            
            String sql="SELECT * FROM MonHoc WHERE "+DuLieu+" LIKE N'%"+dieuKien+"%' COLLATE Vietnamese_CI_AI";
            
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                String maMH = rs.getString("maMonHoc");
                String tenMH = rs.getString("tenMonHoc");
                String tinChi= rs.getString("soTinChi");
                String hocPhi= rs.getString("hocPhi");
            
                MonHoc mh= new MonHoc(maMH,tenMH,tinChi,hocPhi);
                list.add(mh);
            }
            
                BUS.closeConnection(conn);

                }catch (SQLException e){
                    e.printStackTrace(); 
                }
            return list;   
        }
    
    public static ArrayList<MonHoc> selectBySpecialCondition(MonHoc t) {
        ArrayList<MonHoc> list =new ArrayList<MonHoc>();
        try{
            //Buoc 1:Ket noi
            Connection conn= BUS.getConnection();

            //Buoc 2:
            Statement st=conn.createStatement();
            
            //Buoc 3:
            String maMH=t.getMaMH();
            String tenMH=t.getTenMH();
            String tinChi=t.getTinChi();
            String hocPhi=t.getHocPhi();
            
            boolean flag=false;
            
            String sql="SELECT * FROM SinhVien WHERE 1=1 ";
            if(!maMH.isEmpty()){
                sql +="AND maMonHoc LIKE '%"+maMH+"%'";
                flag=true;
            }
            if(!tenMH.isEmpty()){
                sql +="AND tenMonHoc LIKE N'%"+tenMH+"%'";
                flag=true;
            }
            if(!tinChi.isEmpty()){
                sql +="AND soTinChi LIKE '%"+tinChi+"%'";
                flag=true;
            }
            if(!hocPhi.isEmpty()){
                sql +="AND hocPhi LIKE N'%"+hocPhi+"%'";
                flag=true;
            }
            
            if (flag)   sql +="COLLATE Vietnamese_CI_AI";
            
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                String maMH1 = rs.getString("maMonHoc");
                String tenMH1 = rs.getString("tenMonHoc");
                String tinChi1= rs.getString("soTinChi");
                String hocPhi1= rs.getString("hocPhi");
            
                MonHoc mh= new MonHoc(maMH1,tenMH1,tinChi1,hocPhi1);
                list.add(mh);
            }
            
            BUS.closeConnection(conn);

                }catch (SQLException e){
                    e.printStackTrace(); 
                }
            return list;   

        }
}
