/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author lythanhphat9523
 */
public class MonHoc {
    private String maMH;
    private String tenMH;
    private String tinChi;
    private String HocPhi;

    public MonHoc() {
    }

    public MonHoc(String maMH, String tenMH, String tinChi, String HocPhi) {
        this.maMH = maMH;
        this.tenMH = tenMH;
        this.tinChi = tinChi;
        this.HocPhi = HocPhi;
    }

    public String getMaMH() {
        return maMH;
    }

    public void setMaMH(String maMH) {
        this.maMH = maMH;
    }

    public String getTenMH() {
        return tenMH;
    }

    public void setTenMH(String tenMH) {
        this.tenMH = tenMH;
    }

    public String getTinChi() {
        return tinChi;
    }

    public void setTinChi(String tinChi) {
        this.tinChi = tinChi;
    }

    public String getHocPhi() {
        return HocPhi;
    }

    public void setHocPhi(String HocPhi) {
        this.HocPhi = HocPhi;
    }
    
    
}
